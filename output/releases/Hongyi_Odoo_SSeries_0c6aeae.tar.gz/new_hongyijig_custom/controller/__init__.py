# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details

from . import lead_create
from . import risk_calculator
from . import sseries_intake
