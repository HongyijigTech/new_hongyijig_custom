# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details

from . import crm_lead
from . import engineering_reference
from . import governance_master
from . import project_designation
from . import native_forms
from . import programme_template
from . import programme_activity_authority
from . import programme_architecture_authority
from . import programme_dependency_authority
from . import programme_session
from . import programme_gate_checklists
from . import programme_checklist
from . import project_registers
from . import project_document
from . import foundation
from . import project_planning
from . import sor
from . import bop
from . import checklist_gate
from . import execution_quality
from . import commercial_bridge
from . import knowledge_ai
from . import ui_compatibility
from . import sseries_intake
from . import sseries_gateway
from . import sseries_workflow
from . import sseries_pdf_renderer
from . import staging_seat_guard
